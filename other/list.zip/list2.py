products = [
    "Банан", 25,
    "Ананас", 30,
    "Шоколад", 70,
    "Печиво", 90,
    "Помідори", 100,
]
pc = len(products)
print("Товарів:",int(pc/2))
n = 1
for prod in range(0,len(products),2):
    print(str(n)+". "+ products[prod] +" - " + str(products[prod+1]))
    n+=1